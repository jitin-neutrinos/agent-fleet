# state.db schema notes — verified 2026-09-06 on kurama-core (Hermes 0.21.0)

Verified by direct inspection (`select name from sqlite_master where type='table'`) on the default profile. Counts at verification time: 58 sessions, 1,881 messages.

## Tables that matter

### sessions
Core columns: `id` (e.g. `20260906_203907_3fb944`; cron sessions `cron_<job>_<ts>`), `source` (cli/telegram/cron/kanban), `title`, `display_name`, `chat_id`, `last_activity_at` (epoch float), `message_count`, `tool_call_count`, `input_tokens`/`output_tokens`/`estimated_cost_usd`, `model`, `profile_name`, `parent_session_id` (session chains/continuations), `cwd`, `archived`, `pinned`, `hidden`, `tool_names`.

### messages
`id`, `session_id`, `role` (user/assistant/tool), `content`, `tool_name`, `tool_call_id`, `tool_calls`, `timestamp` (epoch float), `token_count`, `reasoning`/`reasoning_content`, `active`, `compacted`, `_compressed_summary`, `display_kind`.

### FTS
`messages_fts` (FTS5 over content/tool_name/tool_calls) + a trigram twin `messages_fts_trigram` — this is what `session_search` queries.

### hosted_rooms* (agent-to-agent layer)
~15 tables: `hosted_rooms` (members, authority gateway), `hosted_room_events` (seq-numbered event log), `hosted_room_links` (member→target transport), `hosted_room_remote_runs`, `hosted_room_policy_*`. All zero rows on this install as of verification — present but unused.

Other: `async_delegations` (delegate_task tracking), `session_model_usage` (per-model token/cost rollups), `delivery_obligations` (pending platform deliveries), `gateway_routing`.

## Worked queries

```python
import sqlite3, time
DB = '/home/notjitin/.hermes/state.db'
db = sqlite3.connect(f'file:{DB}?mode=ro', uri=True)

# Most recently active sessions (liveness = now - last_activity_at small)
for r in db.execute("""select id, source, title, last_activity_at, message_count
                       from sessions order by last_activity_at desc limit 10"""):
    age = int(time.time() - r[3])
    print(r[0], r[1], r[2], f'{age}s ago', f'{r[4]} msgs')

# Tail a live session's message stream
for r in db.execute("""select role, substr(replace(content, char(10), ' '), 1, 120), timestamp
                       from messages where session_id = ? order by id desc limit 6""",
                    ('20260906_203907_3fb944',)):
    print(r)
```

## Cross-profile layout

- Default DB: `~/.hermes/state.db`
- Profiles: `~/.hermes/profiles/{ops,coder,reviewer,researcher}/state.db` (same schema)
- Prefer `session_search(profile='<name>', ...)` for these; fall back to direct read-only SQL.

## External agents (outside state.db)

- Running processes: `ps aux | grep -E 'claude|agy|opencode' | grep -v grep` — the full prompt is visible in the cmdline for `claude -p`.
- Claude Code transcripts: `~/.claude/projects/*.jsonl`.
- Established contract on this machine: scratch dir with `context.md` (in) + `findings.md` / output files + `claude-stdout.log` (out).
