---
name: agent-session-visibility
description: "Use when checking what other sessions or agents are doing, why a gateway message got no reply, or why delivery bounced."
version: 1.1.0
---

# Agent & Session Visibility (single machine)

How to see what every agent on this machine is doing — Hermes sessions (any surface, any profile, live or past) and external CLI agents (Claude Code, agy, opencode). Also covers diagnosing "my message got no reply" / delivery bounces on the messaging gateway.

## Core fact: one SQLite store per profile

Every Hermes session — CLI, Telegram, cron, kanban — writes messages to `~/.hermes/state.db` (SQLite + FTS5) **in real time**. Profiles are isolated: `~/.hermes/profiles/<name>/state.db`. "Live visibility into another session" = reading a DB that updates as it runs. Last-activity granularity is seconds.

Key tables: `sessions` (id, source, title, last_activity_at epoch, message_count, profile_name, parent_session_id), `messages` (session_id, role, content, tool_name, timestamp), `messages_fts` (full-text search). `hosted_rooms*` tables are the built-in agent-to-agent room layer — often present but zero rows (unused).

## Reading other sessions — prefer session_search first

1. **`session_search` tool** (plugin) — discovery / scroll / full-read shapes. Pass `profile=<name>` for **read-only cross-profile access** (e.g. resolve `@session:ops/<id>`). Try this before raw SQL.
2. **Direct SQL** when session_search can't reach (live polling, schema questions):
   ```python
   import sqlite3
   db = sqlite3.connect('/home/notjitin/.hermes/state.db')
   db.execute("select id, title, last_activity_at from sessions order by last_activity_at desc limit 10")
   ```
   Cross-profile: point at `~/.hermes/profiles/<name>/state.db`. Open read-only (`file:...?mode=ro`, uri=True) since the owning process is active and you only read.
3. **Liveness check**: `time.time() - last_activity_at` — under ~120s means the session is probably still running.

## External CLI agents (not Hermes)

Claude Code / agy / opencode transcripts are NOT in state.db. Visibility options, laziest first:
- **`ps aux | grep -E 'claude|agy|opencode'`** — proves it's running and shows the exact prompt it was given (cmdline for `claude -p`).
- **Shared workspace contract** — the runner writes `context.md` into a scratch dir, agent writes `findings.md`/output files there; stdout goes to a log file. Tail those. This is the established pattern on this machine.
- Claude Code raw transcripts: `~/.claude/projects/*.jsonl` (read-only inspection).

## Agent-to-agent messaging

- Hermes↔Hermes coordination writes go through the **kanban board** (`~/.hermes/kanban.db`) — the intended shared write surface. Cross-profile session reads are read-only by design; don't fight it.
- `hosted_rooms` layer exists in the schema for true rooms/events but is typically unused — treat as future option, not working infrastructure, until verified non-empty.
- A shared append-only `agent-bus.jsonl` (one JSON line per status change) is the cheap fallback if file-contract isn't enough. Build only on request.

## Pitfalls

- `sqlite3` CLI may not be installed on the host — use Python's stdlib `sqlite3`, never `pip install` anything for this.
- Profile DBs are per-profile: a session not found in the default DB may live in `profiles/<name>/state.db`. Check `~/.hermes/profiles/` before concluding "not found".
- `state.db` is the canonical store; `~/.hermes/sessions/` holds request dumps and jsonl transcripts — noisier, use only when DB isn't enough.
- Read-only discipline: never write to another profile's state.db or a live session's DB rows.
- **"No reply" ≠ DB problem**: check the gateway drain state FIRST (`grep 'Restart deferred' ~/.hermes/logs/gateway.log`) before treating a missing inbound message as a delivery bug — during an update drain the bot bounces new turns by design, and the DB simply never receives them. See `references/state-db-schema.md` → Gateway turn/delivery behavior.
- **Proactive pushes to Telegram don't need the agent session**: read `TELEGRAM_BOT_TOKEN` + `TELEGRAM_HOME_CHANNEL` from `~/.hermes/.env` (filter comments) and POST to `https://api.telegram.org/bot<tok>/sendMessage` (urlencode chat_id/text/parse_mode) — works even while the gateway is mid-restart, and returns a message_id you can report as delivery proof.
- **Recurring status reports = cron with a DB-reading prompt**: create via `cronjob_manage(action='create', schedule='5m', deliver='telegram:<chat_id>', repeat=<N>, continuity=true)` whose prompt queries state.db read-only for the target session's last messages and reports done/in-progress/pending. Bound `repeat` (e.g. 24×5m = 2h) so a finished job doesn't ping forever; `[SILENT]` suppresses no-change deliveries.
- **Finding the user's live interactive terminal session**: `ps aux | grep hermes` filtered past gateway/dashboard/kernel/supervisor — the interactive chat is the remaining `python .../hermes` with a `pts/N` TTY. Read `/proc/<pid>/cwd` and compare the process start time against a config file's mtime to know whether that session loaded a given config change (MCP registrations, hook changes load at session startup only). Deliver a notice INTO the visible terminal by writing text to `/dev/pts/N` (displays without injecting keystrokes into the TUI); the user still restarts the session to load new config.

## References

- `references/state-db-schema.md` — verified table/column inventory, worked query examples, and gateway turn/delivery behavior (update-restart drain, delivery confirmation, crash forensics).
