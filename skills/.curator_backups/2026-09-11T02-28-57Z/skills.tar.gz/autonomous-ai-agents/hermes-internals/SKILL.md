---
name: hermes-internals
description: "Use when editing Hermes SOUL.md, prompts, or guardrails."
version: 1.0.0
---

# Hermes Internals — prompt anatomy, SOUL.md, guardrail surface

Class-level know-how for answering "where do the agent's instructions/guardrails actually live and how do I review or change them" — runtime system prompt, SOUL.md identity files, memory injection, enforcement config. Complements the bundled `hermes-agent` skill (which covers configuration and features, not prompt internals).

## The four layers (strongest binding first)

1. **Hardcoded core** — built at runtime by `~/.hermes/hermes-agent/agent/system_prompt.py` (`build_system_prompt`, ~1,170 lines) plus `agent/prompt_builder.py` (tool docs + tool-use enforcement, ~2,500 lines). Overwritten on updates; not a customization target, but the review reference for what always binds.
2. **SOUL.md identity** — `$HERMES_HOME/SOUL.md`, loaded verbatim into every session, spliced into the prompt right after the hardcoded persona block. This is the user's main customization lever. Per-profile variants: `~/.hermes/profiles/<name>/SOUL.md`. Edits take effect on the NEXT session, not the running one.
3. **Memory injection** — `~/.hermes/memories/MEMORY.md` + `USER.md` (profile dirs likewise), dumped near the end of the prompt. Hard char budget; imperative phrasing reads as directive.
4. **Enforcement config** — `config.yaml` keys (`approvals.mode`, `security.redact_secrets`, `privacy.redact_pii`, `command_allowlist`) and `~/.hermes/hooks/`. Only layer with real teeth. Never hand-edit config.yaml — use `hermes config set`.

Also auto-injected when present: project context files (`.hermes.md` / `AGENTS.md` / `CLAUDE.md`, 20 KB cap, first-match-wins discovery) and skills (SKILL.md bodies load on demand; only name+description sit in the prompt catalog).

## Rendering the actual runtime prompt

The prompt is assembled at runtime from dozens of agent attributes, so you cannot just cat one file. A minimal FakeAgent stub works — validated 2026-09-06, produced a faithful 12.7 KB render. Use `scripts/render_runtime_prompt.py` under this skill.

Stub contract discovered by iteration (each AttributeError names the next requirement):
- `load_soul_identity()` → returns SOUL.md text
- `valid_tool_names` → a **set** (membership-tested), not a method
- `_tool_use_enforcement` → "auto" (string; `__getattr__` returning False breaks it)
- `__getattr__` fallback: `[]` for plugin/section names, `""` for names ending in text/prompt, `False` for `is_/has_/should_/use_` prefixes, `[]` otherwise

## Pitfalls

- **Gateway self-block**: terminal commands issued from inside the gateway process cannot restart/stop the gateway (SIGTERM would kill the issuer). `hermes gateway restart` must run in a separate shell outside the gateway.
- **MCP server trust gate**: `mcp_servers.<name>.trust: untrusted` in config.yaml blocks every write-capable tool call on that server with `"The user did not approve running write-capable MCP tool 'X' on untrusted server 'Y'"` — read-only calls still pass. Fix: `hermes config set mcp_servers.<name>.trust trusted`, then a NEW session (`/reset` or `/restart`); trust is read at startup. Headless dead-end (validated 2026-09-07): in an unattended session with `approvals.mode: manual`, the agent CANNOT flip trust itself — `patch`/`write_file` refuse config.yaml outright ("agent cannot modify security-sensitive configuration"), and even `hermes config set` routes through the terminal approval gate where nobody is present to approve, so every path (including the tool call itself) fails closed. Do not retry-loop; the correct move is one plain-English message to the user: the exact `hermes config set ...` line (or the one-line `trust:` edit), then `/restart` — after which the pending action becomes a one-call job. Also mine `session_search` for the earlier session that hit the block: it usually names the exact command the user is referring to.
- **Prompt caching is sacred**: never mutate past context, toolsets, or the system prompt mid-conversation. Any enhancement workflow must target files read at session start (SOUL.md, memory, config), then start a new session.
- `system_prompt.py`/`prompt_builder.py` are versioned source — quote them for review, never patch them as "customization"; changes vanish on update and can break the cached-prompt invariant.
- The rendered prompt is ~12–13 KB static + memory/skills catalogs; the runtime prompt the user asked to "enhance" is mostly the SOUL.md section plus config enforcement.

## References

- `references/prompt-anatomy.md` — section-by-section order of the rendered prompt and an intent→file intervention table.
- `scripts/render_runtime_prompt.py` — runnable FakeAgent stub that renders the live system prompt to a text file.
